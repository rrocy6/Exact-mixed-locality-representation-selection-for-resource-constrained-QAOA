"""Golden regression tests."""
