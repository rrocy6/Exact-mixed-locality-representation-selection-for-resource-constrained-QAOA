﻿import pathlib
import subprocess
import sys

log = pathlib.Path(sys.argv[1])
with log.open("wb") as stream:
    result = subprocess.run(
        [sys.executable, *sys.argv[2:]],
        stdout=stream,
        stderr=subprocess.STDOUT,
    )
print(log.read_text(encoding="utf-8", errors="replace")[-6000:])
sys.exit(result.returncode)
